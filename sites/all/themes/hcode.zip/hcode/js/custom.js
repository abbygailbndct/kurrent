(function($) {
  $(document).ready(function() {
    // Expand the menu
    $('li.expanded ul').addClass('hide');
    $('li.expanded').click(function() {
      $(this).toggleClass('clicked');
      $(this).find('ul').toggleClass('hide');
    });
  });
})(jQuery);
