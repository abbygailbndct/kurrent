<li <?php print $attributes;?> class="mega-menu-column <?php print str_replace(array('span12', 'span'), array('megamenu-column-single', 'margin-right-0 col-sm-'), $classes);?>">
  <?php print $tb_items;?>
</li>