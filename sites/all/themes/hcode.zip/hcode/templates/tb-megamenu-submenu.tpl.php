<ul <?php print $attributes;?> class="dropdown-menu mega-menu panel-collapse collapse <?php print $classes;?>" id="collapse<?php print $parent['link']['mlid']; ?>" >
  <?php print $rows; ?>
</ul>
