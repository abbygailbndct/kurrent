<ul id = "<?php print $menu_name; ?>" class = "nav navbar-nav navbar-right panel-group">
  <?php print $content;?>
</ul>